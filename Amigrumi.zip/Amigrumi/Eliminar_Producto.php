<?php
// Eliminar producto
if(isset($_POST['eliminar'])) {
    include("Conexion.php");
    $id = $_POST['id'];
    $sql = "DELETE FROM productos WHERE Id='$id'";
    if(mysqli_query($con, $sql)) {
        header("Location: Admin.php"); // Recargar la página
        exit;
    } else {
        echo "Error al eliminar el producto: " . mysqli_error($con);
    }
}
?>