<?php
// Iniciar la sesión
session_start();

// Destruye la sesión
session_destroy();

// Manda a la vista sin deresho
header("Location: Index.html");
exit;
?>