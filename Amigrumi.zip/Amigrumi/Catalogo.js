document.addEventListener("DOMContentLoaded", function () {
  const agregarBtns = document.querySelectorAll(".agregar-btn");
  const carritoItems = document.querySelector(".carrito-items");

  agregarBtns.forEach((btn) => {
    btn.addEventListener("click", function () {
      const productId = this.getAttribute("data-producto-id");
      // Ahora puedes usar productId para identificar qué producto se está agregando
      // y realizar las operaciones necesarias.
    });
  });
});
