<?php
include "Conexion.php";

$nombre = $_POST['nombre'];
$material = $_POST['material'];
$dimensiones = $_POST['dimensiones'];
$precio = $_POST['precio'];
$categoria = $_POST['categoria'];
$imagen = $_POST['imagen'];

$sql=mysqli_query ($con, "INSERT INTO productos (Nombre, Material, Dimensiones, Precio, Categoria, Imagen) 
        VALUES ('$nombre', '$material', '$dimensiones', '$precio', '$categoria', '$imagen')");

if($sql){
    header("Location: Admin.php");
}else{
    echo "Error al registrar";
}
?>