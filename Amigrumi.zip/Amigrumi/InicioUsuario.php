<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Index/Amigurumi</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400..700&display=swap");
    </style>
    <link rel="stylesheet" href="Index.css" />
  </head>
  <body>
    <header>
      <div class="contenedor">
        <h1 class="titulo">Tu amigo Amigurumi</h1>
        <input type="checkbox" id="menu-bar" />
        <label class="icon-menu" for="menu-bar"></label>
        <nav class="menu">
          <a href="InicioUsuario.php">Inicio</a>
          <a href="Catalogo.php">Catalogo</a>
          <a href="#">Carrito</a>
          <a href="#">Contacto</a>
          <a>
            <?php
              session_start();
              if (isset($_SESSION['usuario'])) {
                echo $_SESSION['usuario'];
              } elseif (isset($_SESSION['admin'])) {
                echo "Admin";
              } else {
                echo "Invitado";
              }
            ?>
          </a>
          <a href="logout.php">Cerrar Sesión</a>
        </nav>
      </div>
    </header>

    <section id="baner">
      <img class="img" src="Imagenes/logoami.png" alt="center" />
      <div class="contenedor">
        <h2>Figuras de crochet</h2>
        <p>
          Figuras de crochet de cualquier tematica incluso hasta personalizados
        </p>
      </div>
    </section>

    <section class="blanco">
      <h2 class="pt-2">Bienvenid@ a tu pagina de confianza Tu Amigurumi</h2>
      <h2 class="mision">Misión</h2>
      <div class="contenedor">
        <div class="blancoC">
          <div>
            <p class="pt-5">
              Nuestra misión es ofrecer figuras de crochet de alta calidad y
              creatividad, que llenen de alegría y diversión a nuestros
              clientes. Nos comprometemos a satisfacer las necesidades
              individuales de cada cliente, ofreciendo un catálogo extenso de
              personajes y temáticas, así como la posibilidad de personalizar
              cada pieza según sus preferencias y deseos. Trabajamos con pasión
              y dedicación para crear productos únicos que sean apreciados y
              disfrutados por personas de todas las edades.
            </p>
          </div>
        </div>

        <div class="frame-slideer">
          <ul>
            <li><img src="Imagenes/1.jpg" alt="" /></li>
            <li><img src="Imagenes/2.jpg" alt="" /></li>
            <li><img src="Imagenes/3.jpg" alt="" /></li>
          </ul>
        </div>
      </div>
    </section>

    <section class="negro">
      <h2 class="pt-2">¿Quienes somos?</h2>
      <div class="contenedor">
        <div class="blancoC">
          <div>
            <div class="frame-slideer">
              <ul>
                <li><img src="Imagenes/4.jpg" alt="" /></li>
                <li><img src="Imagenes/5.jpg" alt="" /></li>
                <li><img src="Imagenes/6.jpg" alt="" /></li>
              </ul>
            </div>
          </div>
          <div>
            <p class="pt-5">
              Somos un negocio especializado en la creación de figuras de
              crochet únicas y encantadoras. Nos destacamos por nuestra
              habilidad para dar vida a una amplia variedad de personajes y
              temáticas, desde adorables animales hasta populares superhéroes y
              personajes de películas. Nuestro catálogo abarca una amplia
              selección de opciones listas para ser adquiridas, pero también
              ofrecemos la opción de personalización total para aquellos que
              desean un producto único y exclusivo. En "Tu Amigo Amigurumi", la
              calidad y la atención al detalle son nuestra prioridad. Cada pieza
              es cuidadosamente elaborada a mano por nuestros talentosos
              artesanos, utilizando materiales de alta calidad para garantizar
              durabilidad y realismo. Valoramos la creatividad y la expresión
              individual, y nos esforzamos por superar las expectativas de
              nuestros clientes en cada creación. Nuestro objetivo es no solo
              proporcionar productos excepcionales, sino también ofrecer una
              experiencia de compra satisfactoria y personalizada. Nos
              enorgullece ofrecer un servicio al cliente excepcional, brindando
              asistencia y orientación en cada paso del proceso de compra.
            </p>
            <a style="text-align: center" href="Catalogo.php">Catalogo</a>
          </div>
        </div>
      </div>
    </section>

    <section>
      <h2 class="pt-2">Vision</h2>
      <div class="contenedor">
        <div class="blancoC">
          <div>
            <p class="pt-5">
              Nuestra visión es convertirnos en el referente líder en la
              industria de amigurumis, reconocidos por nuestra excelencia en
              calidad, innovación y servicio al cliente. Nos esforzamos por
              expandir nuestro catálogo, explorar nuevas técnicas y colaborar
              con artistas para ofrecer una amplia gama de opciones creativas y
              emocionantes. Aspiramos a ser la primera opción para aquellos que
              buscan regalos especiales y personalizados, y a mantenernos a la
              vanguardia de las tendencias en el mundo del crochet y el diseño.
            </p>
          </div>
          <div>
            <div class="frame-slideer">
              <ul>
                <li><img src="Imagenes/7.jpg" alt="" /></li>
                <li><img src="Imagenes/8.jpg" alt="" /></li>
                <li><img src="Imagenes/9.jpg" alt="" /></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="footer">
      <div class="contenedor">
        <div class="footerC">
          <p>Redes Sociales:</p>
        </div>
        <div>
          <a href="https://www.facebook.com/amigurumiscrochetgdl?locale=es_LA">
            Facebook
          </a>
        </div>
        <div>
          <a href="https://www.instagram.com/tuamigoamigurumi/"> Instagram </a>
        </div>
        <div>
          <p>Contacto Directo: 3322122381</p>
        </div>
      </div>
    </section>
  </body>
</html>
