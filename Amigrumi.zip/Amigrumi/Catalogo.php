<?php
// Verifica si la sesión está activa
session_start();
if(!isset($_SESSION['usuario']) || empty($_SESSION['usuario'])) {
    // La sesión no está activa, redirige al usuario a la página de inicio de sesión
    header("Location: login.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Catalogo</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400..700&display=swap");
    </style>
    <link rel="stylesheet" href="Catalogo.css?ts=<?=time()?>" />
</head>
<body>
<header>
    <div class="contenedor">
        <h1 class="titulo">Tu amigo Amigurumi</h1>
        <input type="checkbox" id="menu-bar" />
        <label class="icon-menu" for="menu-bar"></label>
        <nav class="menu">
            <a href="InicioUsuario.php">Inicio</a>
            <a href="Catalogo.php">Catalogo</a>
            <a href="#">Contacto</a>
            <a>
                <?php
                if (session_status() === PHP_SESSION_NONE) {
                    session_start();
                }
                if (isset($_SESSION['usuario'])) {
                    echo $_SESSION['usuario'];
                } elseif (isset($_SESSION['admin'])) {
                    echo "Admin";
                } else {
                    echo "Invitado";
                }
                ?>
            </a>
            <a href="logout.php">Cerrar Sesión</a>
        </nav>
    </div>
</header>

<section id="banner">
    <img class="img" src="Imagenes/logoami.png" />
    <div class="contenedor">
        <h2>Figuras de crochet</h2>
        <p>
            Figuras de crochet de cualquier tematica incluso hasta personalizados
        </p>
    </div>
</section>
<br />
<h1 class="tit">Catalogo</h1>
<br />

<main>
    <section class="container">
        <?php
        include("Conexion.php");
        $sql=mysqli_query($con,"SELECT * FROM productos");
        while($row = mysqli_fetch_array($sql) ){?>
        <div class="card">
            <a href="#">
                <figure class="image-box" style="background-image: url('<?php echo $row['Imagen'] ?>');"></figure>
            </a>
            <div class="contener">
                <p><?php echo $row['Nombre'] ?></p>
                <p><?php echo $row['Material'] ?></p>
                <p><?php echo $row['Dimensiones'] ?></p>
                <p><?php echo $row['Precio'] ?></p>
                <p><?php echo $row['Categoria'] ?></p>

                <input type="hidden" name="producto_id" value="<?php echo $row['Id'] ?>">
                <input type="hidden" name="nombre_producto" value="<?php echo $row['Nombre'] ?>">
                <input type="hidden" name="material_producto" value="<?php echo $row['Material'] ?>">
                <input type="hidden" name="dimensiones_producto" value="<?php echo $row['Dimensiones'] ?>">
                <input type="hidden" name="precio_producto" value="<?php echo $row['Precio'] ?>">
            </div>
            <button class="agregar-btn" data-producto-id="<?php echo $row['Id'] ?>">Agregar</button>
        </div>
        <?php }?>
    </section>
    <!--Carrito de compras-->
    <div class="carrito" id="carrito">
        <div class="header-carrito">
            <h2>Tu Carrito</h2>
        </div>

        <div class="carrito-items">
        </div>
        <div class="carrito-total">
            <div class="fila">
                <strong>Tu Total</strong>
                <span class="carrito-precio-total">
              $0.00
            </span>
            </div>
            <button class="btn-pagar">Pagar <i class="fa-solid fa-bag-shopping"></i> </button>
        </div>
    </div>
</main>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const agregarBtns = document.querySelectorAll('.agregar-btn');
        const carritoItems = document.querySelector('.carrito-items');
        const carritoTotal = document.querySelector('.carrito-precio-total');

        // Función para eliminar un elemento del carrito
        function eliminarProducto(event) {
            const btnEliminar = event.target.closest('.btn-eliminar');
            if (btnEliminar) {
                btnEliminar.parentElement.remove();
                calcularTotal();
            }
        }

        // Función para disminuir la cantidad de un producto en el carrito
        function disminuirCantidad(event) {
            const btnRestar = event.target.closest('.restar-cantidad');
            if (btnRestar) {
                const inputCantidad = btnRestar.nextElementSibling;
                let cantidad = parseInt(inputCantidad.value);
                if (cantidad > 1) {
                    cantidad--;
                    inputCantidad.value = cantidad;
                    calcularTotal();
                }
            }
        }

        // Función para aumentar la cantidad de un producto en el carrito
        function aumentarCantidad(event) {
            const btnSumar = event.target.closest('.sumar-cantidad');
            if (btnSumar) {
                const inputCantidad = btnSumar.previousElementSibling;
                let cantidad = parseInt(inputCantidad.value);
                cantidad++;
                inputCantidad.value = cantidad;
                calcularTotal();
            }
        }

        // Función para calcular el total del carrito
        function calcularTotal() {
            const precios = document.querySelectorAll('.carrito-item-precio');
            let total = 0;
            precios.forEach(precio => {
                total += parseFloat(precio.textContent.replace('$', '').replace(',', '').trim());
            });
            carritoTotal.textContent = `$${total.toFixed(2)}`;
        }

        // Agregar event listeners a los botones de eliminar, restar y sumar
        carritoItems.addEventListener('click', eliminarProducto);
        carritoItems.addEventListener('click', disminuirCantidad);
        carritoItems.addEventListener('click', aumentarCantidad);

        // Función para agregar un producto al carrito
        function agregarProducto(nombre, precio, imagen) {
            const carritoItem = document.createElement('div');
            carritoItem.classList.add('carrito-item');
            carritoItem.innerHTML = `
              <img src="${imagen}" width="80px" alt="${nombre}">
              <div class="carrito-item-detalles">
                <span class="carrito-item-titulo">${nombre}</span>
                <div class="selector-cantidad">
                  <i class="fa-solid fa-minus restar-cantidad"></i>
                  <input type="text" value="1" class="carrito-item-cantidad" disabled>
                  <i class="fa-solid fa-plus sumar-cantidad"></i>
                </div>
                <span class="carrito-item-precio">$${precio}</span>
              </div>
              <button class="btn-eliminar">
                <i class="fa-solid fa-trash"></i>
              </button>
            `;
            carritoItems.appendChild(carritoItem);
            calcularTotal();
        }

        // Agregar event listener a los botones de agregar
        agregarBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const card = this.closest('.card');
                const nombre = card.querySelector('p:nth-of-type(1)').textContent;
                const precio = card.querySelector('p:nth-of-type(4)').textContent;
                const imagen = card.querySelector('.image-box').style.backgroundImage.slice(5, -2);
                agregarProducto(nombre, precio, imagen);
            });
        });

        // Calcular el total inicial del carrito
        calcularTotal();
    });

    // Agregar event listener al botón de pagar
    const btnPagar = document.querySelector('.btn-pagar');
      btnPagar.addEventListener('click', function() {
       // Redireccionar al archivo PHP que genera el PDF y lo envía por correo
      window.location.href = 'generar_pdf.php';
    });
</script>
<section class="footer">
  <div class="contenedor">
    <div class="footerC">
      <p>Redes Sociales:</p>
    </div>
    <div>
      <a href="https://www.facebook.com/amigurumiscrochetgdl?locale=es_LA">
        Facebook
      </a>
    </div>
    <div>
      <a href="https://www.instagram.com/tuamigoamigurumi/"> Instagram </a>
    </div>
    <div>
      <p>Contacto Directo: 3322122381</p>
    </div>
  </div>
</section>
</body>
</html>                                                                                      