<?php
    session_start();
    // Verifica si la sesión está activa y si el usuario está correctamente autenticado
    if(!isset($_SESSION['usuario']) || empty($_SESSION['usuario'])) {
        // La sesión no está activa o el usuario no está correctamente autenticado, redirige al usuario a la página de inicio de sesión
   
        $usuario=$_SESSION['usuario'];


        require('fpdf186/fpdf.php');
        require('Conexion.php');

        // Crear instancia de FPDF
        $pdf = new FPDF('P', 'mm', 'A4');
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 16);

        // Título
        $pdf->Cell(0, 10, 'Resumen de Pedido', 0, 1, 'C');

        // Datos del Usuario
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(0, 10, 'Datos del Usuario:', 0, 1);
        $pdf->Cell(0, 10, 'Nombre: ' . $usuario, 0, 1);
        // Aquí puedes añadir más datos como dirección, email, teléfono, etc.

        // Lista de Productos
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, 'Productos en el Carrito:', 0, 1);
        $pdf->SetFont('Arial', '', 12);

        // Obtener los productos del carrito
        if(isset($_SESSION['carrito'])) {
            foreach ($_SESSION['carrito'] as $producto) {
                $pdf->Cell(0, 10, $producto['NombreProd'] . ' - Precio: $' . $producto['PrecioProduct'], 0, 1);
                // Puedes añadir más detalles de los productos si lo deseas
            }
        } else {
            $pdf->Cell(0, 10, 'Carrito vacío', 0, 1);
        }

        // Calcular y mostrar el total
        $total = 0;
        foreach ($_SESSION['carrito'] as $producto) {
            $total += $producto['PrecioProduct'];
        }
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell(0, 10, 'Total: $' . $total, 0, 1);

        // Guardar el PDF
        $pdf->Output('Resumen_pedido_' . $usuario . '.pdf', 'F');

        // Envío del PDF por correo electrónico
        $to = $email;
        $from = "tuemail@example.com";
        $subject = "Resumen de Pedido";
        $message = "Adjuntamos el resumen de tu pedido.";

        $filename = 'Resumen_pedido_' . $usuario . '.pdf';
        $attachment = chunk_split(base64_encode(file_get_contents($filename)));
        $boundary = md5(date('r', time()));

        $headers = "From: $from\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";

        $body = "--$boundary\r\n";
        $body .= "Content-Type: text/plain; charset=ISO-8859-1\r\n";
        $body .= "Content-Transfer-Encoding: base64\r\n";
        $body .= "\r\n" . chunk_split(base64_encode($message)) . "\r\n";

        $body .= "--$boundary\r\n";
        $body .= "Content-Type: application/pdf; name=\"$filename\"\r\n";
        $body .= "Content-Disposition: attachment; filename=\"$filename\"\r\n";
        $body .= "Content-Transfer-Encoding: base64\r\n";
        $body .= "\r\n" . $attachment . "\r\n";
        $body .= "--$boundary--";

        if (mail($to, $subject, $body, $headers)) {
            // Redireccionar o mostrar un mensaje de éxito
            header("Location: Catalogo.php");
            exit;
        } else {
            // Manejar el fallo del envío de correo
            echo "Error al enviar el correo electrónico.";  
        }
    }
?>          